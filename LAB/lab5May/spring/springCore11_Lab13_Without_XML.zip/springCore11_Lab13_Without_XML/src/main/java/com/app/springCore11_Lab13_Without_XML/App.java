package com.app.springCore11_Lab13_Without_XML;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import model.Company;
import model.Employee;
import spring.config.SpringConfig;

public class App {
	public static void main(String[] args) {
		ApplicationContext apc = new AnnotationConfigApplicationContext(SpringConfig.class);

		Company compObj = apc.getBean("comp", Company.class);
		System.out.println(compObj);

		Employee empObj = apc.getBean("employee", Employee.class);
		System.out.println(empObj);

		((AbstractApplicationContext) apc).close();
	}
}
