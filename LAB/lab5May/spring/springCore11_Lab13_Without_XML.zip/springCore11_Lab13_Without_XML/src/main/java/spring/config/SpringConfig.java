package spring.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import model.Company;
import model.Employee;

@Configuration
public class SpringConfig {

	@Bean("comp")
	public Company company() {
		return new Company("Infosys", "Mumbai", "MSR4356");
	}

	@Bean
	public Employee employee() {
		return new Employee(101, "Usman", 120000, company());
	}
}
