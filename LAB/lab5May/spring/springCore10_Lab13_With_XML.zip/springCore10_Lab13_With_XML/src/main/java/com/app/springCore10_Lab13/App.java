package com.app.springCore10_Lab13;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import model.Company;
import model.Employee;

public class App {
	public static void main(String[] args) {
		ApplicationContext apc = new ClassPathXmlApplicationContext("config.xml");

		Company compObj = apc.getBean("company", Company.class);
		System.out.println("~Company Details~ \n" + compObj + "\n");

		Employee empObj = apc.getBean("employee", Employee.class);
		System.out.println("~Employee Details~ \n" + empObj + "\n");

		((AbstractApplicationContext) apc).close();
	}
}
